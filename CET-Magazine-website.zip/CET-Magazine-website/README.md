# CET Magazine

Website for my college magazine publish.
Check it out at [CET Magazine](https://cetmagazine.ml)
